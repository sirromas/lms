SDK LICENSE AGREEMENT

This Software Development Kit ("SDK") License Agreement ("Agreement") is between
you (both the individual downloading the SDK and any legal entity on behalf of
which such individual is acting) ("You" or "Your") and Authorize.Net LLC
("Authorize.Net").

IT IS IMPORTANT THAT YOU READ CAREFULLY AND UNDERSTAND THIS AGREEMENT. BY
CLICKING THE "I ACCEPT" BUTTON OR AN EQUIVALENT INDICATOR OR BY DOWNLOADING,
INSTALLING OR USING THE SDK OR THE DOCUMENTATION, YOU AGREE TO BE BOUND BY THIS
AGREEMENT.

1. DEFINITIONS
    1. "Application(s)" means software programs that You develop to operate with
       the Gateway using components of the Software.
    2. "Documentation" means the materials made available to You in connection
       with the Software by or on behalf of Authorize.Net pursuant to this
       Agreement.
    3. "Gateway" means any electronic payment platform maintained and operated
       by Authorize.Net and any of its affiliates.
    4. "Software" means all of the software included in the software development
       kit made available to You by or on behalf of Authorize.Net pursuant to
       this Agreement, including but not limited to sample source code, code
       snippets, software tools, code libraries, sample applications,
       Documentation and any upgrades, modified versions, updates, and/or
       additions thereto, if any, made available to You by or on behalf of
       Authorize.Net pursuant to this Agreement.

2. GRANT OF LICENSE; RESTRICTIONS
    1. Limited License. Subject to and conditioned upon Your compliance with the
       terms of this Agreement, Authorize.Net hereby grants to You a limited,
       revocable, non-exclusive, non-transferable, royalty-free license during
       the term of this Agreement to: (a) in any country worldwide, use,
       reproduce, modify, and create derivative works of the components of the
       Software solely for the purpose of developing, testing and manufacturing
       Applications; (b) distribute, sell or otherwise provide Your Applications
       that include components of the Software to Your end users; and (c) use
       the Documentation in connection with the foregoing activities. The
       license to distribute Applications that include components of the
       Software as set forth in subsection (b) above includes the right to grant
       sublicenses to Your end users to use such components of the Software as
       incorporated into such Applications, subject to the limitations and
       restrictions set forth in this Agreement.
    2. Restrictions. You shall not (and shall have no right to): (a) make or
       distribute copies of the Software or the Documentation, in whole or in
       part, except as expressly permitted pursuant to Section 2.1; (b) alter or
       remove any copyright, trademark, trade name or other proprietary notices,
       legends, symbols or labels appearing on or in the Software or
       Documentation; (c) sublicense (or purport to sublicense) the Software or
       the Documentation, in whole or in part, to any third party except as
       expressly permitted pursuant to Section 2.1; (d) distribute or otherwise
       provide all or any portion of the Software (including as incorporated
       into Applications) in any country listed in Appendix 1; (e) engage in any
       activity with the Software, including the development or distribution of
       an Application, that interferes with, disrupts, damages, or accesses in
       an unauthorized manner the Gateway or platform, servers, or systems of
       Authorize.Net, any of its affiliates, or any third party; (f) make any
       statements that Your Application is "certified" or otherwise endorsed, or
       that its performance is guaranteed, by Authorize.Net or any of its
       affiliates; or (g) otherwise use or exploit the Software or the
       Documentation for any purpose other than to develop and distribute
       Applications as expressly permitted by this Agreement.
    3. Ownership. You shall retain ownership of Your Applications developed in
       accordance with this Agreement, subject to Authorize.Net's ownership of
       the Software and Documentation (including Authorize.Net's ownership of
       any portion of the Software or Documentation incorporated in Your
       Applications). You acknowledge and agree that all right, title and
       interest in and to the Software and Documentation shall, at all times, be
       and remain the exclusive property of Authorize.Net and that You do not
       have or acquire any rights, express or implied, in the Software or
       Documentation except those rights expressly granted under this Agreement.
    4. No Support. Authorize.Net has no obligation to provide support,
       maintenance, upgrades, modifications or new releases of the Software.
    5. Open Source Software. You hereby acknowledge that the Software may
       contain software that is distributed under "open source" license terms
       ("Open Source Software"). You shall review the Documentation in order to
       determine which portions of the Software are Open Source Software and are
       licensed under such Open Source Software license terms. To the extent any
       such license requires that Authorize.Net provide You any rights with
       respect to such Open Source Software that are inconsistent with the
       limited rights granted to You in this Agreement, then such rights in the
       applicable Open Source Software license shall take precedence over the
       rights and restrictions granted in this Agreement, but solely with
       respect to such Open Source Software. You acknowledge that the Open
       Source Software license is solely between You and the applicable licensor
       of the Open Source Software and that Your use, reproduction and
       distribution of Open Source Software shall be in compliance with
       applicable Open Source Software license. You understand and agree that
       Authorize.Net is not liable for any loss or damage that You may
       experience as a result of Your use of Open Source Software and that You
       will look solely to the licensor of the Open Source Software in the event
       of any such loss or damage.
    6. License to Authorize.Net. In the event You choose to submit any
       suggestions, feedback or other information or materials related to the
       Software or Documentation or Your use thereof (collectively, "Feedback")
       to Authorize.Net, You hereby grant to Authorize.Net a worldwide,
       non-exclusive, royalty-free, transferable, sublicensable, perpetual and
       irrevocable license to use and otherwise exploit such Feedback in
       connection with the Software, Documentation, and other products and
       services.
    7. Use.
        1. You represent, warrant and agree to use the Software and write
           Applications only for purposes permitted by (i) this Agreement; (ii)
           applicable law and regulation, including, without limitation, the
           Payment Card Industry Data Security Standard (PCI DSS); and (iii)
           generally accepted practices or guidelines in the relevant
           jurisdictions. You represent, warrant and agree that if You use the
           Software to develop Applications for general public end users, that
           You will protect the privacy and legal rights of those users. If the
           Application receives or stores personal or sensitive information
           provided by end users, it must do so securely and in compliance with
           all applicable laws and regulations, including card association
           regulations. If the Application receives Authorize.Net account
           information, the Application may only use that information to access
           the end user's Authorize.Net account. You represent, warrant and
           agree that You are solely responsible for (and that neither
           Authorize.Net nor its affiliates have any responsibility to You or to
           any third party for): (i) any data, content, or resources that You
           obtain, transmit or display through the Application; and (ii) any
           breach of Your obligations under this Agreement, any applicable third
           party license, or any applicable law or regulation, and for the
           consequences of any such breach.

3. WARRANTY DISCLAIMER; LIMITATION OF LIABILITY
    1. Disclaimer. THE SOFTWARE AND THE DOCUMENTATION ARE PROVIDED ON AN "AS IS"
       AND "AS AVAILABLE" BASIS WITH NO WARRANTY. YOU AGREE THAT YOUR USE OF THE
       SOFTWARE AND THE DOCUMENTATION IS AT YOUR SOLE RISK AND YOU ARE SOLELY
       RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM OR OTHER DEVICE OR
       LOSS OF DATA THAT RESULTS FROM SUCH USE. TO THE FULLEST EXTENT
       PERMISSIBLE UNDER APPLICABLE LAW, AUTHORIZE.NET AND ITS AFFILIATES
       EXPRESSLY DISCLAIM ALL WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, WITH
       RESPECT TO THE SOFTWARE AND THE DOCUMENTATION, INCLUDING ALL WARRANTIES
       OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, SATISFACTORY
       QUALITY, ACCURACY, TITLE AND NON-INFRINGEMENT, AND ANY WARRANTIES THAT
       MAY ARISE OUT OF COURSE OF PERFORMANCE, COURSE OF DEALING OR USAGE OF
       TRADE. NEITHER AUTHORIZE.NET NOR ITS AFFILIATES WARRANT THAT THE
       FUNCTIONS OR INFORMATION CONTAINED IN THE SOFTWARE OR THE DOCUMENTATION
       WILL MEET ANY REQUIREMENTS OR NEEDS YOU MAY HAVE, OR THAT THE SOFTWARE OR
       DOCUMENTATION WILL OPERATE ERROR FREE, OR THAT THE SOFTWARE OR
       DOCUMENTATION IS COMPATIBLE WITH ANY PARTICULAR OPERATING SYSTEM.
    2. Limitation of Liability. IN NO EVENT SHALL AUTHORIZE.NET AND ITS
       AFFILIATES BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL
       OR PUNITIVE DAMAGES, OR DAMAGES FOR LOSS OF PROFITS, REVENUE, BUSINESS,
       SAVINGS, DATA, USE OR COST OF SUBSTITUTE PROCUREMENT, INCURRED BY YOU OR
       ANY THIRD PARTY, WHETHER IN AN ACTION IN CONTRACT OR TORT, EVEN IF
       AUTHORIZE.NET HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES OR IF
       SUCH DAMAGES ARE FORESEEABLE. IN NO EVENT SHALL THE ENTIRE LIABILITY OF
       AUTHORIZE.NET AND AFFILIATES ARISING FROM OR RELATING TO THIS AGREEMENT
       OR THE SUBJECT MATTER HEREOF EXCEED ONE HUNDRED U.S. DOLLARS ($100). THE
       PARTIES ACKNOWLEDGE THAT THE LIMITATIONS OF LIABILITY IN THIS SECTION 3.2
       AND IN THE OTHER PROVISIONS OF THIS AGREEMENT AND THE ALLOCATION OF RISK
       HEREIN ARE AN ESSENTIAL ELEMENT OF THE BARGAIN BETWEEN THE PARTIES,
       WITHOUT WHICH AUTHORIZE.NET WOULD NOT HAVE ENTERED INTO THIS AGREEMENT.

4. INDEMNIFICATION. You shall indemnify, hold harmless and, at Authorize.Net's
   request, defend Authorize.Net and its affiliates and their officers,
   directors, employees, and agents from and against any claim, suit or
   proceeding, and any associated liabilities, costs, damages and expenses,
   including reasonable attorneys' fees, that arise out of relate to: (i) Your
   Applications or the use or distribution thereof and Your use or distribution
   of the Software or the Documentation (or any portion thereof including Open
   Source Software), including, but not limited to, any allegation that any such
   Application or any such use or distribution infringes, misappropriates or
   otherwise violates any intellectual property (including, without limitation,
   copyright, patent, and trademark), privacy, publicity or other rights of any
   third party, or has caused the death or injury of any person or damage to any
   property; (ii) Your alleged or actual breach of this Agreement; (iii) the
   alleged or actual breach of this Agreement by any party to whom you have
   provided Your Applications, the Software or the Documentation or (iii) Your
   alleged or actual violation of or non-compliance with any applicable laws,
   legislation, policies, rules, regulations or governmental requirements
   (including, without limitation, any laws, legislation, policies, rules,
   regulations or governmental requirements related to privacy and data
   collection).

5. TERMINATION. This Agreement and the licenses granted to you herein are
   effective until terminated. Authorize.Net may terminate this Agreement and
   the licenses granted to You at any time. Upon termination of this Agreement,
   You shall cease all use of the Software and the Documentation, return to
   Authorize.Net or destroy all copies of the Software and Documentation and
   related materials in Your possession, and so certify to Authorize.Net. Except
   for the license to You granted herein, the terms of this Agreement shall
   survive termination.

6. CONFIDENTIAL INFORMATION
    1. You hereby agree (i) to hold Authorize.Net's Confidential Information in
       strict confidence and to take reasonable precautions to protect such
       Confidential Information (including, without limitation, all precautions
       You employ with respect to Your own confidential materials), (ii) not to
       divulge any such Confidential Information to any third person; (iii) not
       to make any use whatsoever at any time of such Confidential Information
       except as strictly licensed hereunder, (iv) not to remove or export from
       the United States or re-export any such Confidential Information or any
       direct product thereof, except in compliance with, and with all licenses
       and approvals required under applicable U.S. and foreign export laws and
       regulations, including, without limitation, those of the U.S. Department
       of Commerce.
    2. "Confidential Information" shall mean any data or information, oral or
       written, treated as confidential that relates to Authorize.Net's past,
       present, or future research, development or business activities,
       including without limitation any unannounced products and services, any
       information relating to services, developments, inventions, processes,
       plans, financial information, customer data, revenue, transaction volume,
       forecasts, projections, application programming interfaces, Software and
       Documentation.

7. General Terms
    1. Law. This Agreement and all matters arising out of or relating to this
       Agreement shall be governed by the internal laws of the State of
       California without giving effect to any choice of law rule. This
       Agreement shall not be governed by the United Nations Convention on
       Contracts for the International Sales of Goods, the application of which
       is expressly excluded. In the event of any controversy, claim or dispute
       between the parties arising out of or relating to this Agreement, such
       controversy, claim or dispute shall be resolved in the state or federal
       courts in Santa Clara County, California, and the parties hereby
       irrevocably consent to the jurisdiction and venue of such courts.
    2. Logo License. Authorize.Net hereby grants to You the right to use,
       reproduce, publish, perform and display Authorize.Net logo solely in
       accordance with the current Authorize.Net brand guidelines.
    3. Severability and Waiver. If any provision of this Agreement is held to be
       illegal, invalid or otherwise unenforceable, such provision shall be
       enforced to the extent possible consistent with the stated intention of
       the parties, or, if incapable of such enforcement, shall be deemed to be
       severed and deleted from this Agreement, while the remainder of this
       Agreement shall continue in full force and effect. The waiver by either
       party of any default or breach of this Agreement shall not constitute a
       waiver of any other or subsequent default or breach.
    4. No Assignment. You may not assign, sell, transfer, delegate or otherwise
		   dispose of, whether voluntarily or involuntarily, by operation of law or
		   otherwise, this Agreement or any rights or obligations under this
		   Agreement without the prior written consent of Authorize.Net, which may
       be withheld in Authorize.Net's sole discretion. Any purported assignment,
       transfer or delegation by You shall be null and void. Subject to the
       foregoing, this Agreement shall be binding upon and shall inure to the
       benefit of the parties and their respective successors and assigns.
    5. Government Rights. If You (or any person or entity to whom you provide
       the Software or Documentation) are an agency or instrumentality of the
       United States Government, the Software and Documentation are "commercial
       computer software" and "commercial computer software documentation," and
       pursuant to FAR 12.212 or DFARS 227.7202, and their successors, as
       applicable, use, reproduction and disclosure of the Software and
       Documentation are governed by the terms of this Agreement.
    6. Export Administration. You shall comply fully with all relevant export
       laws and regulations of the United States, including, without limitation,
       the U.S. Export Administration Regulations (collectively "Export
       Controls"). Without limiting the generality of the foregoing, You shall
       not, and You shall require Your representatives not to, export, direct or
       transfer the Software or the Documentation, or any direct product
       thereof, to any destination, person or entity restricted or prohibited by
       the Export Controls.
    7. Privacy. In order to continually innovate and improve the Software,
       Licensee understands and agrees that Authorize.Net may collect certain
       usage statistics including but not limited to a unique identifier,
       associated IP address, version number of software, and information on
       which tools and/or services in the Software are being used and how they
       are being used.
    8. Entire Agreement; Amendments. This Agreement constitutes the entire
       agreement between the parties and supersedes all prior or contemporaneous
       agreements or representations, written or oral, concerning the subject
       matter of this Agreement. Authorize.Net may make changes to this
       Agreement, Software or Documentation in its sole discretion. When these
       changes are made, Authorize.Net will make a new version of the Agreement,
       Software or Documentation available on the website where the Software is
       available. This Agreement may not be modified or amended by You except in
       a writing signed by a duly authorized representative of each party. You
       acknowledge and agree that

Authorize.Net has not made any representations, warranties or agreements of any
kind, except as expressly set forth herein.

Authorize.Net Software Development Kit (SDK) License Agreement

v. December 12, 2013

1
